package com.wwp.QA;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Task.class}, version = 1) // declare Task table into database
public abstract class AppDatabase extends RoomDatabase {

    public abstract TaskDao taskDao();

}
